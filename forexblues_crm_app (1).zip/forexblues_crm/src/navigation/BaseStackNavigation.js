import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import { Platform } from 'react-native';
import Colors from '../constants/Colors';
import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/HomeScreen';
import NewLeadWithDetailScreen from '../screens/NewLeadWithDetailScreen';
import ProfileScreen from '../screens/ProfileScreen';
import NewLeadWithOutDetailScreen from '../screens/NewLeadWithoutDetailScreen';
import LeadsListScreen from '../screens/LeadsListScreen';
import RecontactLeadScreen from '../screens/RecontactLeadScreen';
import MasterSearchScreen from '../screens/MasterSearchScreen';
import ChangePasswordScreen from '../screens/ChangePasswordScreen';
import LogIssueScreen from '../screens/LogIssueScreen';
import LeadDetailsScreen from '../screens/ViewDetailsScreen';

const DefaultConfigOptions = {
     headerStyle: {
          backgroundColor: Platform.OS === 'android' ? Colors.primaryColor : ' white',
     },
     headerTitleStyle: {
          fontFamily: 'open-sans'
     },
     headerShown: false,
     headerTintColor: Platform.OS === 'android' ? 'white' : Colors.primaryColor
};

const BaseStackNavigator = createStackNavigator({
     Login: LoginScreen,
     Home: HomeScreen,
     NewLead: NewLeadWithDetailScreen,
     NewLeadWithout: NewLeadWithOutDetailScreen,
     Profile: ProfileScreen,
     LeadsList: LeadsListScreen,
     Recontact: RecontactLeadScreen,
     MasterSearch: MasterSearchScreen,
     ChangePassword: ChangePasswordScreen,
     LogIssue: LogIssueScreen,
     LeadDetails: LeadDetailsScreen
}, {
     initialRouteName: 'Home',
     defaultNavigationOptions: DefaultConfigOptions
});

export default createAppContainer(BaseStackNavigator);