export default {
     primaryColor: '#4A148C',
     accentColor: '#FF6F00'
}