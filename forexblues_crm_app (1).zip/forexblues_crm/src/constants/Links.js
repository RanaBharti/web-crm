export default {
     baseUrl: 'https://forexblues.herokuapp.com/',
}