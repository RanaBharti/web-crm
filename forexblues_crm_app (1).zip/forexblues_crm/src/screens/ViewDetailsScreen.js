import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity, ScrollView, Button, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const getStatusText = (status) => {

     if (status == '1') {
          return 'Demo';
     }
     else if (status == '2') {
          return 'Email';
     }

     else if (status == '3') {
          return 'Dormant';
     }

     else if (status == '4') {
          return 'Unreachable';
     }

     else if (status == '5') {
          return 'Wrong Number';
     }

     else if (status == '6') {
          return 'Others';
     }

     else if (status == '7') {
          return 'Later';
     }

     else if (status == '8' || status == '9' || status == '10' || status == '12') {
          return 'Others';
     }

     else if (status == '11') {
          return 'Comment';
     }

     else if (status == '13') {
          return 'Converted';
     }
     else {
          return 'N/A';
     }
}

const LeadDetailsScreen = ({ navigation }) => {

     const [data, setData] = useState(navigation.state.params.leadData);

     var diffDays = '';

     if (data.feedback[data.feedback.length - 1].status == '1') {
          const date1 = new Date(data.feedback[data.feedback.length - 1].date);
          const date2 = new Date();
          const diffTime = Math.abs(date2 - date1);
          diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
     }

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>

               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>

          <Text style={{ ...styles.title, }}>
               Lead Details
          </Text>
          <View style={{
               backgroundColor: 'white', borderRadius: 10, marginVertical: 5,
               elevation: 5,
               shadowOpacity: 0.26,
               shadowColor: 'black',
               shadowRadius: 10,
               padding: 10,
               shadowOffset: { width: 0, height: 2 },
          }}>
               <Text style={{ ...styles.title, fontSize: 18 }}>
                    {data.fullName} - {data.companyName}
               </Text>

               <Text style={{ ...styles.title, fontSize: 14 }}>
                    {data.address}, {data.city}, {data.state}
               </Text>
               <View style={{ backgroundColor: 'rgba(220,220,220,1)', padding: 10, borderRadius: 5 }}>

                    <Text style={{ ...styles.title, fontSize: 16, color: 'blue', textDecorationLine: 'underline' }}>
                         Feedback History
                    </Text>
                    {data.feedback.map((element, index) => {
                         return (<Text key={index} style={{ ...styles.title, fontSize: 14, color: 'red' }}>
                              {getStatusText(element.feedback)} on {new Date(element.date).toDateString()}{element.notes ? "\n" : null}{element.notes ? element.notes : null}
                         </Text>);
                    })}
               </View>
               {diffDays ? <Text style={{ ...styles.title, fontSize: 14, color: 'blue' }}>
                    Demo taken {diffDays} days before.
               </Text> : null}
               <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Source: {data.source}.
               </Text>
               <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Business Type: {data.businessType}.
               </Text>

               <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Business Volume: {data.businessVolume}.
               </Text>

               <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Email: {data.email}
               </Text>

               {data.comment ? <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Comment: {data.comment}
               </Text> : null}

               {data.later ? <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Later: {new Date(data.later).toDateString()}
               </Text> : null}

               <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Primary Mobile: {data.mobile1}
               </Text>

               <Text style={{ ...styles.title, fontFamily: 'open-sans', fontSize: 14 }}>
                    Alternate Mobile: {data.mobile2}
               </Text>
               {data.status != '13' && data.status != '3' ? <TouchableOpacity activeOpacity={.5} onPress={() => {
                    navigation.navigate('Recontact', {
                         leadData: navigation.state.params.leadData
                    });
               }}>
                    <View style={styles.buttonBackground}>
                         <Text style={styles.buttonText}>Contact</Text>
                    </View>
               </TouchableOpacity> : null}
          </View>
     </View>);
}

const styles = StyleSheet.create({
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          paddingHorizontal: 20,
          paddingTop: 50,
          justifyContent: 'center',

     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 5,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          paddingHorizontal: 10,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 14,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     dropDownTextStyle: {
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'red'
     },
     dropDownContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5,
          marginTop: 10,
     },
     itemContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderRadius: 5,
          padding: 10,
          marginTop: 5,
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
});

export default LeadDetailsScreen;