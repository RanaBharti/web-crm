import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity, ScrollView, Button, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { onChange } from 'react-native-reanimated';
import axios from 'axios';
import Links from '../constants/Links';

const getStatusText = (status)=>{

     if(status == '1'){
          return 'Demo';
     }
     else if(status == '2'){
          return 'Email';
     }

     else if(status == '3'){
          return 'Dormant';
     }

     else if(status == '4'){
          return 'Unreachable';
     }

     else if(status == '5'){
          return 'Wrong Number';
     }

     else if(status == '6'){
          return 'Others';
     }

     else if(status == '7'){
          return 'Later';
     }

     else if(status == '8' || status == '9'||status == '10'||status == '12'){
          return 'Others';
     }

     else if(status == '11'){
          return 'Comment';
     }

     else if(status == '13'){
          return 'Converted';
     }
     else{
          return 'N/A';
     }
}

const MasterSearchScreen = ({ navigation }) => {

     const [searchQuery, setSearchQuery] = useState('');
     const [searchResult, setSearchResult] = useState([]);
     const [errorText, setErrorText] = useState('');

     const handleSearch = (searchQuery) => {
          if (!searchQuery) {
               setErrorText('Kindly enter a query before searching.');
               return;
          }
          else {
               console.log(searchQuery);
               setErrorText('');
               axios({
                    method: 'post',
                    url: `${Links.baseUrl}api/master-search`,
                    headers: {
                         common: {
                              Accept: 'application/x-www-form-urlencoded',
                         }
                    },
                    data: { query: searchQuery }
               }).then(function (response) {
                    setErrorText('');
                    setSearchResult([]);
                    if (response.data.success) {
                         if (response.data.data) {
                              console.log(response.data.data);
                              setSearchResult([response.data.data]);
                         }
                         else {
                              setErrorText('No results found!');
                         }
                    }
                    else {
                         setErrorText('No results found!');
                    }
               })
          }
     }

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>

               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
               <TextInput
                    style={{ ...styles.input, flex: 1 }}
                    onChangeText={setSearchQuery}
                    value={searchQuery}
                    caretHidden={false}
                    placeholder='Search through the database'
               />

               <View style={{ width: 10, }} />
               <TouchableOpacity activeOpacity={.5} onPress={() => {
                    handleSearch(searchQuery);
               }}>
                    <View style={styles.buttonBackground}>
                         <Ionicons name="ios-search" size={24} color="white" />
                    </View>
               </TouchableOpacity>
          </View>

          <Text style={{ ...styles.title, }}>
               Master Search
          </Text>
          {errorText?<Text style={{ ...styles.errorText, }}>
               {errorText}
          </Text>:null}
          <FlatList data={searchResult} keyExtractor={(item)=>item._id} contentContainerStyle={{ justifyContent: 'center', padding: 10 }} renderItem={({ item }) => {
               const statusText = getStatusText(item.status);
               return (<View style={{
                    backgroundColor: 'white', borderRadius: 10, marginVertical: 5,
                    elevation: 5,
                    shadowOpacity: 0.26,
                    shadowColor: 'black',
                    shadowRadius: 10,
                    padding: 10,
                    shadowOffset: { width: 0, height: 2 },
               }}>
                    <Text style={styles.title}>
                         {item.companyName}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 14, color: 'red' }}>
                         Status: {statusText}
                    </Text>

                    <Text style={{ ...styles.title, fontSize: 12, color: 'red' }}>
                         {getStatusText(item.feedback[item.feedback.length - 1].feedback)} on {new Date(item.feedback[item.feedback.length - 1].date).toDateString()}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         {item.fullName}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         {item.address}, {item.city}, {item.state}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         Mobile: {item.mobile1}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         Alternate Mobile: {item.mobile2}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         Email: {item.email}
                    </Text>
               </View>);
          }} />
     </View>);
}

const styles = StyleSheet.create({
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          paddingHorizontal: 20,
          paddingTop: 50,
          justifyContent: 'center',

     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 5,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          paddingHorizontal: 10,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 14,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     dropDownTextStyle: {
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'red'
     },
     dropDownContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5,
          marginTop: 10,
     },
     itemContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderRadius: 5,
          padding: 10,
          marginTop: 5,
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
     errorText: {
          fontFamily: 'open-sans-bold',
          fontSize: 12,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'red',
          alignItems: 'center',
          textAlign: 'center'
     },
});

export default MasterSearchScreen;