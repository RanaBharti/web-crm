import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity, ScrollView, BackHandler } from 'react-native';
import * as Progress from 'react-native-progress';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Linking } from 'react-native';
import moment from 'moment';
import * as SecureStore from 'expo-secure-store';


async function getValueFor(key) {
     return await SecureStore.getItemAsync(key);
}

async function save(key, value) {
     await SecureStore.setItemAsync(key, value);
}

async function deleteItem(key) {
     await SecureStore.deleteItemAsync(key);
}


const NewLeadWithDetailScreen = ({ navigation }) => {
     const [source, setSource] = useState([
          { label: 'Calling', value: 'calling' },
          { label: 'Referral', value: 'referral' },
          { label: 'SMS', value: 'sms' },
          { label: 'Email', value: 'email' },
          { label: 'Social Media', value: 'social_media' },
          { label: 'Digital Marketing', value: 'digital_marketing' },
          { label: 'Not available', value: 'not_available' }
     ]);

     const [businessType, setBusinessType] = useState([
          { label: 'Exporter', value: 'exporter' },
          { label: 'Importer', value: 'importer' },
          { label: 'EXP & IMP Both', value: 'exp_imp' },
          { label: 'Money Changer', value: 'money_changer' },
          { label: 'Forex Trader', value: 'forex_trader' },
          { label: 'NRI/Individual', value: 'nri' },
          { label: 'Other', value: 'other' },
          { label: 'Not available', value: 'not_available' }

     ]);
     const [businessVolume, setBusinessVolume] = useState([
          { label: 'Below \$50k USD', value: '50k' },
          { label: 'Above \$1lakh USD', value: '1lakh' },
          { label: '\$2lakh USD', value: '2lakh' },
          { label: '\$4-5lakh USD', value: '4lakh' },
          { label: '\$10lakh+ USD', value: '10lakh' },
          { label: 'Did not disclose', value: 'did_not_disclose' },
          { label: 'Not available', value: 'not_available' }

     ]);

     const [feedback, setFeedback] = useState([
          { label: 'Interested & Add me', value: '1' },
          { label: 'Drop an Email Only', value: '2' },
          { label: 'Not Interested', value: '3' },
          { label: 'Busy / Unreachable', value: '4' },
          { label: 'Wrong / Incorrect Number', value: '5' },
          { label: 'Disconnected the call', value: '6' },
          { label: 'Out of station, call later', value: '7' },
          { label: 'Already taking from others', value: '8' },
          { label: 'Not Doing EXIM Business', value: '9' },
          { label: 'Small Business', value: '10' },
          { label: 'Leave a Comment', value: '11' },
          { label: 'Did not pick', value: '12' },
     ]);

     const [sourceOpen, setSourceOpen] = useState(false);
     const [feedbackOpen, setFeedbackOpen] = useState(false);
     const [businessTypeOpen, setBusinessTypeOpen] = useState(false);
     const [businessVolumeOpen, setBusinessVolumeOpen] = useState(false);


     const [valueSource, setValueSource] = useState(null);
     const [valueFeedback, setValueFeedback] = useState(null);
     const [valueBusinessType, setValueBusinessType] = useState(null);
     const [valueBusinessVolume, setValueBusinessVolume] = useState(null);
     const [fullName, setFullName] = useState('');
     const [companyName, setCompanyName] = useState('');
     const [address, setAddress] = useState('');
     const [city, setCity] = useState('');
     const [state, setState] = useState('');
     const [email, setEmail] = useState('');
     const [mobile, setMobile] = useState('');
     const [aMobile, setAMobile] = useState('');
     const [comment, setComment] = useState('');
     const [date, setDate] = useState(new Date());
     const [notes, setNotes] = useState('');
     const [mode, setMode] = useState('date');
     const [show, setShow] = useState(false);
     const [errorText, setErrorText] = useState('');
     const [leadsCount, setLeadsCount] = useState(-1);
     const [savedLeadsCount, setSavedLeadsCount] = useState(0);

     const onChange = (event, selectedDate) => {
          const currentDate = selectedDate || date;
          setShow(Platform.OS === 'ios');
          setDate(currentDate);
     };

     const showMode = (currentMode) => {
          setShow(true);
          setMode(currentMode);
     };

     const showDatepicker = () => {
          showMode('date');
     };

     const showTimepicker = () => {
          showMode('time');
     };

     useEffect(() => {
          if (valueFeedback != '7') {
               setDate(new Date());
          }
          if (valueFeedback != '11') {
               setComment('');
          }
     }, [valueFeedback])

     useEffect(() => {
          checkForPreviousSavedLead();
     }, [])

     const handleBackButtonClick = () => {
          navigation.pop();
     }

     const checkForPreviousSavedLead = async () => {
          let tempNewLead = await getValueFor('tempWithDetailLead');
          if (tempNewLead) {
               tempNewLead = JSON.parse(tempNewLead);
               console.log(tempNewLead.source);
               setValueSource(tempNewLead.source);
               setValueFeedback(tempNewLead.status);
               setValueBusinessType(tempNewLead.businessType);
               setValueBusinessVolume(tempNewLead.businessVolume);
               setFullName(tempNewLead.fullName);
               setCompanyName(tempNewLead.companyName);
               setAddress(tempNewLead.address);
               setCity(tempNewLead.city);
               setState(tempNewLead.state);
               setEmail(tempNewLead.email);
               setMobile(tempNewLead.mobile1);
               setAMobile(tempNewLead.mobile2);
               setComment(tempNewLead.comment);
          }
          else {
               fetchFromList();
          }

          let newLeadsList = await getValueFor('newLeadsList');
          let leadsList = await getValueFor('leadsList');
          if (newLeadsList) {
               newLeadsList = JSON.parse(newLeadsList);
               setLeadsCount(newLeadsList.length);
          }
          else {
               setLeadsCount(0);
          }

          if (leadsList) {
               leadsList = JSON.parse(leadsList);
               setSavedLeadsCount(leadsList.length);
          }

     }

     const fetchFromList = async () => {
          var fullNewLeadsList = await getValueFor('newLeadsList');
          fullNewLeadsList = JSON.parse(fullNewLeadsList);
          let newLeadsList = {};
          if (newLeadsList) {
               newLeadsList = fullNewLeadsList[0];
          }
          else {
               return;
          }
          setFullName(newLeadsList.fullName);
          setCompanyName(newLeadsList.companyName);
          setAddress(newLeadsList.address);
          setCity(newLeadsList.city);
          setState(newLeadsList.state);
          setEmail(newLeadsList.email);
          setMobile(newLeadsList.mobile1);
          setAMobile(newLeadsList.mobile2);
          await fullNewLeadsList.splice(0, 1);
          await save('newLeadsList', JSON.stringify(fullNewLeadsList));
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          const dataObject = {
               status: valueFeedback,
               fullName: newLeadsList.fullName,
               companyName: newLeadsList.companyName,
               address: newLeadsList.address,
               city: newLeadsList.city,
               state: newLeadsList.state,
               email: newLeadsList.email,
               mobile1: newLeadsList.mobile1,
               mobile2: newLeadsList.mobile2,
               agentName: userInfo._id,
               businessType: valueBusinessType,
               businessVolume: valueBusinessVolume,
               source: valueSource,
               comment: comment,
               later: date,
               date: new Date(),
               feedback: [{
                    date: new Date(),
                    feedback: valueFeedback,
                    status: valueFeedback
               }]
          }
          await save('tempWithDetailLead', JSON.stringify(dataObject));
     }

     const saveTempLead = async () => {
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          const dataObject = {
               status: valueFeedback,
               fullName: fullName,
               companyName: companyName,
               address: address,
               city: city,
               state: state,
               email: email,
               mobile1: mobile,
               mobile2: aMobile,
               agentName: userInfo._id,
               businessType: valueBusinessType,
               businessVolume: valueBusinessVolume,
               source: valueSource,
               comment: comment,
               later: date,
               date: new Date(),
               feedback: [{
                    date: new Date(),
                    feedback: valueFeedback,
                    status: valueFeedback
               }]
          }
          await save('tempWithDetailLead', JSON.stringify(dataObject));
     }

     const saveData = async () => {
          setErrorText('');
          if (!valueFeedback) {
               setErrorText('Select feedback.');
               return;
          }
          if (!valueSource) {
               setErrorText('Select source.');
               return;
          }
          if (!valueBusinessType) {
               setErrorText('Select business type.');
               return;
          }
          if (!valueBusinessVolume) {
               setErrorText('Select business volume.');
               return;
          }
          if (!fullName) {
               setErrorText('Enter name.');
               return;
          }
          if (!companyName) {
               setErrorText('Enter company name.');
               return;
          }
          if (!address) {
               setErrorText('Enter address.');
               return;
          }
          if (!city) {
               setErrorText('Enter city.');
               return;
          }
          if (!state) {
               setErrorText('Enter state.');
               return;
          }
          if (!email) {
               setErrorText('Enter email.');
               return;
          }
          if (!mobile) {
               setErrorText('Enter mobile.');
               return;
          }
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          const dataObject = {
               status: valueFeedback,
               fullName: fullName,
               companyName: companyName,
               address: address,
               city: city,
               state: state,
               email: email,
               mobile1: mobile,
               mobile2: aMobile,
               agentName: userInfo._id,
               businessType: valueBusinessType,
               businessVolume: valueBusinessVolume,
               source: valueSource,
               comment: comment,
               later: date,
               notes: notes,
               date: new Date(),
               feedback: [{
                    date: new Date(),
                    feedback: valueFeedback,
                    status: valueFeedback
               }]
          }
          let leadsList = []
          //GET SAVED LIST
          let savedLeadList = await getValueFor('leadsList');
          //check if exists
          if (savedLeadList) {
               leadsList = JSON.parse(savedLeadList);
          }
          //
          leadsList.push(dataObject);
          await save('leadsList', JSON.stringify(leadsList));
          await deleteItem('tempWithDetailLead');
          setFullName('');
          setCompanyName('');
          setAddress('');
          setCity('');
          setState('');
          setEmail('');
          setMobile('');
          setAMobile('');
          setValueBusinessType(null);
          setValueBusinessVolume(null);
          setValueFeedback(null);
          setValueSource(null);
          checkForPreviousSavedLead();
     }

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>

               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>
          <Text style={{ ...styles.title, }}>
               Your today's progress
          </Text>
          <Progress.Bar progress={(70 - leadsCount) / 70} width={Dimensions.get('window').width - 40} indeterminate={leadsCount == 0 && savedLeadsCount == 0 ? true : false} animationType={'spring'} />
          <View style={{ flexDirection: 'row' }}>
               <View style={{ flex: 1 }}>
                    <DropDownPicker
                         open={sourceOpen}
                         items={source}
                         setOpen={setSourceOpen}
                         setItems={setSource}
                         setValue={setValueSource}
                         value={valueSource}
                         placeholder={'Source'}
                         style={styles.dropDownContainer}
                         zIndex={1111}
                         dropDownContainerStyle={styles.dropDownContainer}
                         customItemLabelStyle={styles.dropDownTextStyle}
                         customItemContainerStyle={styles.itemContainer}
                         textStyle={styles.dropDownTextStyle}
                    />
               </View>
               <View style={{ flex: 1 }}>
                    <DropDownPicker
                         open={businessTypeOpen}
                         items={businessType}
                         setOpen={setBusinessTypeOpen}
                         setItems={setBusinessType}
                         setValue={setValueBusinessType}
                         value={valueBusinessType}
                         placeholder={'Business Type'}
                         style={styles.dropDownContainer}
                         zIndex={1110}
                         dropDownContainerStyle={styles.dropDownContainer}
                         customItemLabelStyle={styles.dropDownTextStyle}
                         customItemContainerStyle={styles.itemContainer}
                         textStyle={styles.dropDownTextStyle}
                    />
               </View>

          </View>
          <DropDownPicker
               open={businessVolumeOpen}
               items={businessVolume}
               setOpen={setBusinessVolumeOpen}
               setItems={setBusinessVolume}
               setValue={setValueBusinessVolume}
               value={valueBusinessVolume}
               placeholder={'Business Volume'}
               style={styles.dropDownContainer}
               zIndex={1109}
               dropDownContainerStyle={styles.dropDownContainer}
               customItemLabelStyle={styles.dropDownTextStyle}
               customItemContainerStyle={styles.itemContainer}
               textStyle={styles.dropDownTextStyle}
          />
          <DropDownPicker
               open={feedbackOpen}
               items={feedback}
               setOpen={setFeedbackOpen}
               setItems={setFeedback}
               setValue={setValueFeedback}
               value={valueFeedback}
               placeholder={'Feedback'}
               style={styles.dropDownContainer}
               zIndex={1108}
               dropDownContainerStyle={styles.dropDownContainer}
               customItemLabelStyle={styles.dropDownTextStyle}
               customItemContainerStyle={styles.itemContainer}
               textStyle={styles.dropDownTextStyle}
          />
          <ScrollView contentContainerStyle={{ paddingBottom: 10 }} style={{ marginBottom: 10 }}>
               <TextInput
                    style={styles.input}
                    onChangeText={setFullName}
                    value={fullName}
                    caretHidden={false}
                    placeholder='Enter Full Name'
               />

               <TextInput
                    style={styles.input}
                    onChangeText={setCompanyName}
                    value={companyName}
                    caretHidden={false}
                    placeholder='Enter Company Name'
               />

               <TextInput
                    style={styles.input}
                    onChangeText={setAddress}
                    value={address}
                    caretHidden={false}
                    placeholder='Enter Address'
               />

               <TextInput
                    style={styles.input}
                    onChangeText={setCity}
                    value={city}
                    caretHidden={false}
                    placeholder='Enter City'
               />

               <TextInput
                    style={styles.input}
                    onChangeText={setState}
                    value={state}
                    caretHidden={false}
                    placeholder='Enter State'
               />

               <TextInput
                    style={styles.input}
                    onChangeText={setNotes}
                    value={notes}
                    caretHidden={false}
                    placeholder='Enter Notes'
               />

               <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>

                    <TextInput
                         style={{ ...styles.input, flex: 2 }}
                         onChangeText={setEmail}
                         value={email}
                         caretHidden={false}
                         placeholder='Enter Email Address'
                         autoCapitalize='none'
                         keyboardType='email-address'
                    />
                    <View style={{ width: 10, }} />
                    <TouchableOpacity style={{ flex: 1 }} activeOpacity={.5} onPress={() => {
                         saveTempLead();
                         Linking.canOpenURL(`mailto:${email}`)
                              .then(supported => {
                                   if (!supported) {
                                        console.log('Cant handle url')
                                   } else {
                                        return Linking.openURL(`mailto:${email}`)
                                   }
                              })
                              .catch(err => {
                                   console.error('An error occurred', err)
                              })
                    }}>
                         <View style={{ ...styles.buttonBackground, width: '100%' }}>
                              <Text style={styles.buttonText}>Email</Text>
                         </View>
                    </TouchableOpacity>
               </View>
               <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>

                    <TextInput
                         style={{ ...styles.input, flex: 2 }}
                         onChangeText={setMobile}
                         value={mobile}
                         caretHidden={false}
                         placeholder='Enter Mobile No.'
                         autoCapitalize='none'
                         keyboardType='phone-pad'
                    />
                    <View style={{ width: 10, }} />
                    <TouchableOpacity style={{ flex: 1 }} activeOpacity={.5} onPress={() => {
                         saveTempLead();
                         Linking.canOpenURL(`tel://${mobile}`)
                              .then(supported => {
                                   if (!supported) {
                                        console.log('Cant handle url')
                                   } else {
                                        return Linking.openURL(`tel://${mobile}`)
                                   }
                              })
                              .catch(err => {
                                   console.error('An error occurred', err)
                              })
                    }}>
                         <View style={{ ...styles.buttonBackground, width: '100%' }}>
                              <Text style={styles.buttonText}>Call</Text>
                         </View>
                    </TouchableOpacity>
               </View>
               <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>

                    <TextInput
                         style={{ ...styles.input, flex: 2 }}
                         onChangeText={setAMobile}
                         value={aMobile}
                         caretHidden={false}
                         placeholder='Enter Alternate No.'
                         autoCapitalize='none'
                         keyboardType='phone-pad'
                    />
                    <View style={{ width: 10, }} />
                    <TouchableOpacity style={{ flex: 1 }} activeOpacity={.5} onPress={() => {
                         saveTempLead();
                         Linking.canOpenURL(`tel://${aMobile}`)
                              .then(supported => {
                                   if (!supported) {
                                        console.log('Cant handle url')
                                   } else {
                                        return Linking.openURL(`tel://${aMobile}`)
                                   }
                              })
                              .catch(err => {
                                   console.error('An error occurred', err)
                              })
                    }}>
                         <View style={{ ...styles.buttonBackground, width: '100%' }}>
                              <Text style={styles.buttonText}>Call</Text>
                         </View>
                    </TouchableOpacity>
               </View>

               {valueFeedback == '11' ? <TextInput
                    style={styles.input}
                    onChangeText={setComment}
                    value={comment}
                    caretHidden={false}
                    placeholder='Enter Comment'
               /> : null}

               {valueFeedback == '7' ? <View style={styles.textBackgroundRegister} zIndex={1107}>
                    <TouchableOpacity activeOpacity={.5} onPress={showDatepicker}>
                         <Text style={new Date().toDateString() == date.toDateString() ? { ...styles.title, color: 'red', fontSize: 14 } : { ...styles.title, color: 'blue', fontSize: 14 }}>
                              {new Date().toDateString() == date.toDateString() ? 'Click here to select a date!' : 'Call later date is ' + date.toDateString()}
                         </Text>

                    </TouchableOpacity>
               </View> : null}

               {show && (
                    <DateTimePicker
                         testID="dateTimePicker"
                         value={date}
                         minimumDate={moment().toDate()}
                         mode={mode}
                         is24Hour={true}
                         display="default"
                         onChange={onChange}
                    />
               )}
               {errorText ? <Text style={{ ...styles.errorText, }}>
                    {errorText}
               </Text> : null}
               <TouchableOpacity activeOpacity={.5} onPress={() => {
                    saveData();
               }}>
                    <View style={styles.buttonBackground}>
                         <Text style={styles.buttonText}>Save</Text>
                    </View>
               </TouchableOpacity>
          </ScrollView>
     </View>);
}

const styles = StyleSheet.create({
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          paddingHorizontal: 20,
          paddingTop: 50,
          justifyContent: 'center',
     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 5,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          width: Dimensions.get('window').width * 0.25,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     dropDownTextStyle: {
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'red'
     },
     dropDownContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5,
          marginTop: 10,
     },
     itemContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderRadius: 5,
          padding: 10,
          marginTop: 5,
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },

     errorText: {
          fontFamily: 'open-sans-bold',
          fontSize: 14,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'red',
          alignItems: 'center',
          textAlign: 'center'
     },
});

export default NewLeadWithDetailScreen;