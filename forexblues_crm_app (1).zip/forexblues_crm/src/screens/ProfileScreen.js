import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, Image, Dimensions, TouchableOpacity, Platform, TouchableNativeFeedback } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import * as Updates from 'expo-updates';
import axios from 'axios';
import Links from '../constants/Links';

const list = [
     { id: 'new_lead', name: 'Calls', color: 'blue', count: 0 },
     { id: 'demo', name: 'Demo', color: 'red', count: 0 },
     { id: 'coverted', name: 'Others', color: 'orange', count: 0 },
     { id: 'dormant', name: 'Converted', color: 'grey', count: 0 },
];

async function save(key, value) {
     await SecureStore.setItemAsync(key, value);
}

async function getValueFor(key) {
     return await SecureStore.getItemAsync(key);
}

async function deleteItem(key) {
     await SecureStore.deleteItemAsync(key);
}

const ProfileScreen = ({ navigation }) => {

     let TouchableCmp = TouchableOpacity;

     if (Platform.OS === 'android' || Platform.Version > 21) {
          TouchableCmp = TouchableNativeFeedback;
     }

     const [name, onChangeName] = useState('');
     const [profileImage, setProfileImage] = useState('https://reactnative.dev/img/tiny_logo.png');

     const [todayList, setTodayList] = useState([]);
     const [monthList, setMonthList] = useState([]);
     const [prevMonthList, setPrevMonthList] = useState([]);



     useEffect(() => {
          handleUserCheck();
     }, []);

     const handleUserCheck = async () => {
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          if (!userInfo) {
               navigation.replace('Login');
               return;
          }
          if (userInfo.name) {
               onChangeName(userInfo.name);
          }
          else {
               onChangeName(userInfo.username);
          }

          if (userInfo.profileImage) {
               setProfileImage(userInfo.profileImage);
          }
          await fetchTodaysCount(userInfo);
          await fetchMonthCount(userInfo);
          await fetchPrevMonthCount(userInfo);
     }

     const fetchTodaysCount = async (userInfo) => {
          const demo = await fetchCount(userInfo._id,'1','counts-date-today');
          const dormant = await fetchCount(userInfo._id,'3','counts-date-today');
          const coverteds = await fetchCount(userInfo._id,'13','counts-date-today');
          var othersCount = Number(await fetchCount(userInfo._id, '6','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '8','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '9','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '10','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '12','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '7','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '2','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '5','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '11','counts-date-today'));
          othersCount += Number(await fetchCount(userInfo._id, '4','counts-date-today'));
          setTodayList([
               { id: 'new_lead', name: 'Dormant', color: 'blue', count: dormant },
               { id: 'demo', name: 'Demo', color: 'red', count: demo },
               { id: 'coverted', name: 'Others', color: 'orange', count:  othersCount },
               { id: 'dormant', name: 'Converted', color: 'grey', count: coverteds },
          ]);  
     }

     const fetchMonthCount = async (userInfo) => {
          const demo = await fetchCount(userInfo._id,'1','counts-date-month');
          const dormant = await fetchCount(userInfo._id,'3','counts-date-month');
          const coverteds = await fetchCount(userInfo._id,'13','counts-date-month');
          var othersCount = Number(await fetchCount(userInfo._id, '6','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '8','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '9','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '10','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '12','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '7','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '2','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '5','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '11','counts-date-month'));
          othersCount += Number(await fetchCount(userInfo._id, '4','counts-date-month'));
          setMonthList([
               { id: 'new_lead', name: 'Dormant', color: 'blue', count: dormant },
               { id: 'demo', name: 'Demo', color: 'red', count: demo },
               { id: 'coverted', name: 'Others', color: 'orange', count:  othersCount },
               { id: 'dormant', name: 'Converted', color: 'grey', count: coverteds },
          ]);  
     }

     const fetchPrevMonthCount = async (userInfo) => {
          const demo = await fetchCount(userInfo._id,'1','counts-date-month-prev');
          const dormant = await fetchCount(userInfo._id,'3','counts-date-month-prev');
          const coverteds = await fetchCount(userInfo._id,'13','counts-date-month-prev');
          var othersCount = Number(await fetchCount(userInfo._id, '6','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '8','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '9','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '10','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '12','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '7','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '2','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '5','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '11','counts-date-month-prev'));
          othersCount += Number(await fetchCount(userInfo._id, '4','counts-date-month-prev'));
          setPrevMonthList([
               { id: 'new_lead', name: 'Dormant', color: 'blue', count: dormant },
               { id: 'demo', name: 'Demo', color: 'red', count: demo },
               { id: 'coverted', name: 'Others', color: 'orange', count:  othersCount },
               { id: 'dormant', name: 'Converted', color: 'grey', count: coverteds },
          ]);  
     }

     const fetchCount = async (userID, status,endpoint) => {
          const response = await axios({
               method: 'post',
               url: status == 'new' ? `${Links.baseUrl}api/new-counts` : `${Links.baseUrl}api/${endpoint}`,
               headers: {
                    common: {
                         Accept: 'application/x-www-form-urlencoded',
                    }
               },
               data: { userID: userID, status: status }
          });
          if (response.data.success) {
               return response.data.lead;
          }
          else {
               return '0';
          }
     }

     // const fetchCountMonth = (status) => {

     // }

     // const fetchCountMonthPrev = (status) => {

     // }

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>

               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>
          <View style={{ flexDirection: 'row', margin: 10, alignItems: 'center' }}>
               <Image
                    style={styles.tinyLogo}
                    source={{
                         uri: profileImage,
                    }}
               />
               <View style={{ width: 5 }} />
               <Text style={{ ...styles.title}}>
                    {name}!
               </Text>
          </View>
          <View style={styles.list}>
               <Text style={{ ...styles.title }}>
                    Today's
               </Text>
               <FlatList contentContainerStyle={{ paddingBottom: 20 }} style={styles.list} data={todayList} numColumns={4} renderItem={({ item }) => {
                    return <View style={styles.gridItem}><TouchableCmp onPress={() => {
                    }}><View style={{ ...styles.container, ...{ backgroundColor: item.color } }}>
                              <Text style={styles.itemtitle}>{item.name}</Text>
                              <View style={{
                                   width: '100%', height: 70, position: 'absolute',
                                   padding: -10,
                                   justifyContent: 'center', alignItems: 'center'
                              }}>
                                   <Text style={styles.itemCount}>{item.count}</Text>
                              </View>
                         </View></TouchableCmp></View>
               }} />
          </View>
          <View style={styles.list}>
               <Text style={{ ...styles.title }}>
                    Month's
               </Text>
               <FlatList contentContainerStyle={{ paddingBottom: 20 }} style={styles.list} data={monthList} numColumns={4} renderItem={({ item }) => {
                    return <View style={styles.gridItem}><TouchableCmp onPress={() => {
                    }}><View style={{ ...styles.container, ...{ backgroundColor: item.color } }}>
                              <Text style={styles.itemtitle}>{item.name}</Text>
                              <View style={{
                                   width: '100%', height: 70, position: 'absolute',
                                   padding: -10,
                                   justifyContent: 'center', alignItems: 'center'
                              }}>
                                   <Text style={styles.itemCount}>{item.count}</Text>
                              </View>
                         </View></TouchableCmp></View>
               }} />
          </View>
          <View style={styles.list}>
               <Text style={{ ...styles.title }}>
                    Previous Month's
               </Text>
               <FlatList contentContainerStyle={{ paddingBottom: 20 }} style={styles.list} data={prevMonthList} numColumns={4} renderItem={({ item }) => {
                    return <View style={styles.gridItem}><TouchableCmp onPress={() => {
                    }}><View style={{ ...styles.container, ...{ backgroundColor: item.color } }}>
                              <Text style={styles.itemtitle}>{item.name}</Text>
                              <View style={{
                                   width: '100%', height: 70, position: 'absolute',
                                   padding: -10,
                                   justifyContent: 'center', alignItems: 'center'
                              }}>
                                   <Text style={styles.itemCount}>{item.count}</Text>
                              </View>
                         </View></TouchableCmp></View>
               }} />
          </View>
          {/* <View style={{ flexDirection: 'row', marginBottom: 50, justifyContent: 'space-between', alignItems: 'center' }}>
               <TouchableOpacity activeOpacity={.5} onPress={() => {
                    navigation.navigate('ChangePassword');
               }}>
                    <View style={styles.buttonBackground}>
                         <Text style={styles.buttonText}>Change Password</Text>
                    </View>
               </TouchableOpacity>
               <TouchableOpacity activeOpacity={.5} onPress={() => {
                    navigation.navigate('LogIssue');
               }}>
                    <View style={styles.buttonBackground}>
                         <Text style={styles.buttonText}>Log Issue</Text>
                    </View>
               </TouchableOpacity>
          </View> */}


          <View style={{ flexDirection: 'row', marginBottom: 50, justifyContent: 'space-between', alignItems: 'center' }}>
               {/* <TouchableOpacity activeOpacity={.5} onPress={() => {
                    navigation.navigate('RegisterFive');
               }}>
                    <View style={styles.buttonBackground}>
                         <Text style={styles.buttonText}>Change Profile Image</Text>
                    </View>
               </TouchableOpacity> */}



               <TouchableOpacity activeOpacity={.5} onPress={async () => {
                    await deleteItem('userInfo');
                    await deleteItem('leadsList');
                    await deleteItem('newLeadsList');
                    await deleteItem('tempNewLead');
                    await deleteItem('tempWithDetailLead');
                    await Updates.reloadAsync();
               }}>
                    <View style={styles.buttonBackground}>
                         <Text style={styles.buttonText}>Logout</Text>
                    </View>
               </TouchableOpacity>
          </View>
     </View>);
}

const styles = StyleSheet.create({
     gridItem: {
          height: 70,
          flex: 1,
          margin: 2,
          borderRadius: 5,
          elevation: 5,
          overflow: Platform.OS === 'android' && Platform.Version >= 15 ? 'hidden' : 'visible',
     },
     tinyLogo: {
          width: 40,
          height: 40,
          shadowOpacity: 0.26,
          shadowColor: 'black',
          shadowRadius: 10,
          shadowOffset: { width: 0, height: 2 },
          borderRadius: 50
     },
     container: {
          height: 70,
          borderRadius: 5,
          padding: 2,
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
          shadowOpacity: 0.26,
          shadowColor: 'black',
          shadowRadius: 10,
          shadowOffset: { width: 0, height: 2 },
     },
     itemCount: {
          fontFamily: 'open-sans-bold',
          fontSize: 20,
          textAlign: 'center',
          color: 'white'
     },
     itemtitle: {
          fontFamily: 'open-sans-bold',
          fontSize: 12,
          textAlign: 'right',
          color: 'white'
     },
     list: {
          flex: 1,
          width: '100%',
          backgroundColor: 'white'
     },
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          paddingHorizontal: 20,
          paddingTop: 50,
          justifyContent: 'center',
     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 50,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          height: 40,
          marginTop: 10,
          padding: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
});

export default ProfileScreen;