import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, Image, Dimensions, TouchableOpacity, Platform, TouchableNativeFeedback } from 'react-native';
import * as Progress from 'react-native-progress';
import * as SecureStore from 'expo-secure-store';
import axios from 'axios';
import Links from '../constants/Links';

async function save(key, value) {
     await SecureStore.setItemAsync(key, value);
}

async function getValueFor(key) {
     return await SecureStore.getItemAsync(key);
}

async function deleteItem(key) {
     await SecureStore.deleteItemAsync(key);
}

const HomeScreen = ({ navigation }) => {

     const [list, setList] = useState([
          { id: 'new_lead', name: 'New Lead', color: 'blue', count: 0 },
          { id: 'demo', name: 'Demo', color: 'red', count: 0 },
          { id: 'coverted', name: 'Converted', color: 'orange', count: 0 },
          { id: 'dormant', name: 'Dormant', color: 'grey', count: 0 },
          { id: 'unreachable', name: 'Unreachable', color: 'darkgreen', count: 0 },
          { id: 'comment', name: 'Comment', color: 'red', count: 0 },
          { id: 'wrong_no', name: 'Wrong No', color: 'lightblue', count: 0 },
          { id: 'email', name: 'Email', color: 'lightgreen', count: 0 },
          { id: 'others', name: 'Others', color: 'pink', count: 0 },
          { id: 'later', name: 'Later', color: 'purple', count: 0 },
     ])

     const [leadsCount, setLeadsCount] = useState(-1);
     const [savedLeadsCount, setSavedLeadsCount] = useState(0);
     const [name, onChangeName] = useState('');
     const [buttonText, setButtonText] = useState('Fetching');

     const [profileImage, setProfileImage] = useState('https://reactnative.dev/img/tiny_logo.png')

     let TouchableCmp = TouchableOpacity;

     const refresh = (data) => {
          handleUserCheck();
     }

     const handleUserCheck = async () => {
          setButtonText('Wait...');
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          if (!userInfo) {
               navigation.replace('Login');
               return;
          }
          if (userInfo.name) {
               onChangeName(userInfo.name);
          }
          else {
               onChangeName(userInfo.username);
          }
          // userInfo = {...userInfo, profileImage:'https://firebasestorage.googleapis.com/v0/b/forexblues-crm.appspot.com/o/uploads%2Fimage_cropper_1630927721705.jpg?alt=media&token=11ab7fb6-7298-48ad-ad3d-cf1dea49cf1a'}
          if (userInfo.profileImage) {
               setProfileImage(userInfo.profileImage);
          }
          var list = [{
               id: 'new_lead', name: 'New Lead', color: 'blue', count: await
                    fetchCount(userInfo._id, 'new')
          },];
          list.push({
               id: 'demo', name: 'Demo', color: 'red', count: await
                    fetchCount(userInfo._id, '1')
          });
          list.push({ id: 'coverted', name: 'Converted', color: 'orange', count: await fetchCount(userInfo._id, '13') });
          list.push({ id: 'dormant', name: 'Dormant', color: 'grey', count: await fetchCount(userInfo._id, '3') });
          list.push({
               id: 'unreachable', name: 'Unreachable', color: 'darkgreen', count: await
                    fetchCount(userInfo._id, '4')
          });
          list.push({ id: 'comment', name: 'Comment', color: 'red', count: await fetchCount(userInfo._id, '11') });
          list.push({ id: 'wrong_no', name: 'Wrong No', color: 'lightblue', count: await fetchCount(userInfo._id, '5') });
          list.push({ id: 'email', name: 'Email', color: 'lightgreen', count: await fetchCount(userInfo._id, '2') });
          var othersCount = Number(await fetchCount(userInfo._id, '6'));
          othersCount += Number(await fetchCount(userInfo._id, '8'));
          othersCount += Number(await fetchCount(userInfo._id, '9'));
          othersCount += Number(await fetchCount(userInfo._id, '10'));
          othersCount += Number(await fetchCount(userInfo._id, '12'));
          list.push({ id: 'others', name: 'Others', color: 'pink', count: othersCount });
          list.push({ id: 'later', name: 'Later', color: 'purple', count: await fetchCount(userInfo._id, '7') });
          setList(list);
          let newLeadsList = await getValueFor('newLeadsList');
          let leadsList = await getValueFor('leadsList');
          if (newLeadsList) {
               newLeadsList = JSON.parse(newLeadsList);
               if (newLeadsList.length > 0) {
                    setLeadsCount(newLeadsList.length);
                    setButtonText('Ready');
               }
               else {
                    setLeadsCount(0);
                    setButtonText('Download');
               }
          }
          else {
               setLeadsCount(0);
               setButtonText('Download');
          }


          if (leadsList) {
               leadsList = JSON.parse(leadsList);
               setSavedLeadsCount(leadsList.length);
               if (leadsList.length > 0) {
                    setButtonText('Upload');
               }
          }
     }

     const fetchCount = async (userID, status) => {
          const response = await axios({
               method: 'post',
               url: status == 'new' ? `${Links.baseUrl}api/new-counts` : `${Links.baseUrl}api/counts`,
               headers: {
                    common: {
                         Accept: 'application/x-www-form-urlencoded',
                    }
               },
               data: { userID: userID, status: status }
          });
          if (response.data.success) {
               return response.data.lead;
          }
          else {
               return '0';
          }
     }

     const downloadLeads = async () => {
          const response = await axios({
               method: 'post',
               url: `${Links.baseUrl}api/new-leads`,
               headers: {
                    common: {
                         Accept: 'application/x-www-form-urlencoded',
                    }
               },
          });
          if (response.data.success) {
               await save('newLeadsList', JSON.stringify(response.data.data));
               handleUserCheck();
          }
          else {
               return '0';
          }
     }

     const uploadLeads = async () => {
          let leadsList = await getValueFor('leadsList');
          leadsList = JSON.parse(leadsList);
          for (let i = 0; i < leadsList.length; i++) {
               const response = await axios({
                    method: 'post',
                    url: `${Links.baseUrl}api/upload-lead`,
                    headers: {
                         common: {
                              Accept: 'application/x-www-form-urlencoded',
                         }
                    },
                    data: leadsList[i]
               });
          }
          await deleteItem('leadsList');
          handleUserCheck();
     }

     if (Platform.OS === 'android' || Platform.Version > 21) {
          TouchableCmp = TouchableNativeFeedback;
     }

     useEffect(() => {
          const subscription = navigation.addListener(
               'didFocus',
               payload => {
                    handleUserCheck();
               }
          );
          return () => {
               subscription.remove();
          }
     }, [])

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground} zIndex={99}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>

               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
               <TouchableOpacity onPress={() => {
                    navigation.navigate('Profile');
               }} activeOpacity={.5} style={styles.tinyLogo}><Image
                         style={styles.tinyLogo}
                         source={{
                              uri: profileImage,
                         }}
                    /></TouchableOpacity>
          </View>
          <Text style={{ ...styles.title, }} zIndex={99}>
               Welcome {name}!
          </Text>
          <View style={styles.list} zIndex={99}>
               <FlatList contentContainerStyle={{ paddingBottom: 20 }} style={styles.list} data={list} numColumns={2} renderItem={({ item }) => {
                    return <View style={styles.gridItem}><TouchableCmp onPress={() => {
                         if (item.id === 'new_lead') {
                              if (leadsCount > 0) {
                                   navigation.navigate('NewLead', {
                                        onGoBack: refresh,
                                   });
                              }
                         }
                         else {
                              navigation.navigate('LeadsList', {
                                   id: item.id,
                                   onGoBack: refresh,
                              });
                         }
                    }}><View style={{ ...styles.container, ...{ backgroundColor: leadsCount == 0 && item.id === 'new_lead' ? 'black' : item.color } }}>
                              <Text style={styles.itemtitle}>{item.name}</Text>
                              <View style={{
                                   width: '100%', height: 150, position: 'absolute',
                                   padding: -10,
                                   justifyContent: 'center', alignItems: 'center'
                              }}>
                                   <Text style={styles.itemCount}>{item.count}</Text>
                              </View>
                         </View></TouchableCmp></View>
               }} />
          </View>

          <View zIndex={100}>
               <Text style={{ ...styles.title, }}>
                    Your today's progress
               </Text>
               <Progress.Bar progress={(70 - leadsCount) / 70} width={Dimensions.get('window').width - 40} indeterminate={leadsCount == 0 && savedLeadsCount == 0 ? true : false} animationType={'spring'} />
               <View style={{ flexDirection: 'row', marginBottom: 10, justifyContent: 'space-between', alignItems: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={() => {
                         navigation.navigate('MasterSearch');
                    }}>
                         <View style={styles.buttonBackground}>
                              <Text style={styles.buttonText}>Search</Text>
                         </View>
                    </TouchableOpacity>

                    <TouchableOpacity activeOpacity={.5} onPress={() => {
                         navigation.navigate('NewLeadWithout', {
                              onGoBack: refresh,
                         });
                    }}>
                         <View style={styles.buttonBackground}>
                              <Text style={styles.buttonText}>Add New</Text>
                         </View>
                    </TouchableOpacity>

                    <TouchableOpacity activeOpacity={.5} onPress={async () => {
                         if (buttonText == 'Upload') {
                              setButtonText('Wait...');
                              await uploadLeads();
                         }
                         else if(buttonText == 'Download') {
                              setButtonText('Wait...');
                              await downloadLeads();
                         }
                    }}>
                         <View style={buttonText == 'Wait...' ? { ...styles.buttonBackground, backgroundColor: 'red' } : styles.buttonBackground}>
                              <Text style={styles.buttonText}>{buttonText}</Text>
                         </View>
                    </TouchableOpacity>
               </View>
          </View>


     </View >);
}

const styles = StyleSheet.create({
     gridItem: {
          height: 150,
          flex: 1,
          margin: 10,
          borderRadius: 10,
          elevation: 5,
          overflow: Platform.OS === 'android' && Platform.Version >= 15 ? 'hidden' : 'visible',
     },
     tinyLogo: {
          width: 40,
          height: 40,
          shadowOpacity: 0.26,
          shadowColor: 'black',
          shadowRadius: 10,
          shadowOffset: { width: 0, height: 2 },
          alignSelf: 'flex-end',
          marginLeft: 'auto',
          borderRadius: 50
     },
     container: {
          height: 150,
          borderRadius: 10,
          padding: 10,
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
          shadowOpacity: 0.26,
          shadowColor: 'black',
          shadowRadius: 10,
          shadowOffset: { width: 0, height: 2 },
     },
     itemCount: {
          fontFamily: 'open-sans-bold',
          fontSize: 24,
          textAlign: 'center',
          color: 'white'
     },
     itemtitle: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          textAlign: 'right',
          color: 'white'
     },
     list: {
          flex: 1,
          width: '100%',
          backgroundColor: 'white'
     },
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          paddingHorizontal: 20,
          paddingTop: 50,
          justifyContent: 'center',
     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 50,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          width: Dimensions.get('window').width * 0.25,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
});

export default HomeScreen;