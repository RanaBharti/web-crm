import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity } from 'react-native';
import axios from 'axios';
import Links from '../constants/Links';
import * as SecureStore from 'expo-secure-store';

async function save(key, value) {
     await SecureStore.setItemAsync(key, value);
}

async function getValueFor(key) {
     let result = await SecureStore.getItemAsync(key);
     if (result) {
          alert("🔐 Here's your value 🔐 \n" + result);
     } else {
          alert('No values stored under that key.');
     }
}

const LoginScreen = ({ navigation }) => {
     const [username, onChangeUsername] = useState(null);
     const [password, onChangePassword] = useState(null);
     const [statusCode, setStatusCode] = useState(500);
     const [errorText, setErrorText] = useState('');

     const handleLogin = (username, password) => {
          if (!username || !password) {
               setErrorText('Kindly fill username and password!');
               return;
          }
          else {
               setErrorText('');
               if (statusCode == 500) {
                    setErrorText('Unable to reach server! Check StatusCode.');
                    return;
               }
               axios({
                    method: 'post',
                    url: `${Links.baseUrl}api/login`,
                    headers: {
                         common: {
                              Accept: 'application/x-www-form-urlencoded',
                         }
                    },
                    data: { username: username, password: password }
               }).then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return {
                              type: "LOGIN_USER",
                              api_response: { success: false }
                         }
                    }
                    else {
                         return response.data;
                    }
               }).catch(function (error) {
                    return {
                         type: "LOGIN_USER",
                         api_response: { success: false }
                    }
               }).then(async (response) => {
                    if (response.success) {
                         await save('userInfo', JSON.stringify(response.data)).then(() => {
                              navigation.replace('Home');
                         });
                    }
                    else {
                         setErrorText('Kindly check username and password!');
                    }
               })
          }
     }

     function checkStatusCode() {
          axios({
               method: 'post',
               url: `${Links.baseUrl}api/status`,

          }).then((response) => {
               setStatusCode(response.data.statusCode);
          });
     }

     

     useEffect(() => {
          checkStatusCode();
     });

     var stylesSC = {};
     if(statusCode == '500'){
          stylesSC = {
               ...styles.statusColor,
               backgroundColor: 'red'
          }
     }
     else if(statusCode == '503'){
          stylesSC = {
               ...styles.statusColor,
               backgroundColor: 'orange'
          }
     }
     else{
          stylesSC = {
               ...styles.statusColor,
               backgroundColor: 'green'
          }
     }


     return (<View style={styles.baseContainer}>
          <View style={styles.statusContainer}>
               <Text style={styles.statusText}>
                    System StatusCode: {statusCode}
               </Text>
               <View style={stylesSC} />
          </View>

          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>
          <Text style={{ ...styles.title, }}>
               Please login back to your account!
          </Text>
          <TextInput
               style={styles.input}
               onChangeText={onChangeUsername}
               value={username}
               caretHidden={false}
               placeholder='Enter your username'
               autoCapitalize='none'
          />
          <TextInput
               style={styles.input}
               onChangeText={onChangePassword}
               value={password}
               caretHidden={false}
               secureTextEntry
               placeholder='Enter your password'
          />
          <TouchableOpacity activeOpacity={.5} onPress={() => {
               handleLogin(username, password);
          }}>
               <View style={styles.buttonBackground}>
                    <Text style={styles.buttonText}>Login</Text>
               </View>
          </TouchableOpacity>
          <Text style={{ ...styles.errorText, }}>
               {errorText}
          </Text>
     </View>);
}

const styles = StyleSheet.create({
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          padding: 20,
          paddingTop: 50,
          justifyContent: 'center',
     },
     statusContainer: {
          position: 'absolute',
          top: 60,
          right: 10,
          flexDirection: 'row'
     },
     statusText: {
          fontFamily: 'open-sans-bold',
          fontSize: 12,
          letterSpacing: 0.6,
          color: 'black',
          marginRight: 10
     },
     statusColor: {
          width: 20,
          borderRadius: 100,
     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 50,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          width: Dimensions.get('window').width * 0.25,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black',
     },
     errorText: {
          fontFamily: 'open-sans-bold',
          fontSize: 12,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'red',
          alignItems: 'center',
          textAlign: 'center'
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
});

export default LoginScreen;