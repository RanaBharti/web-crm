import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity, ScrollView, Button, FlatList, BackHandler } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Progress from 'react-native-progress';
import * as SecureStore from 'expo-secure-store';
import axios from 'axios';
import Links from '../constants/Links';

async function save(key, value) {
     await SecureStore.setItemAsync(key, value);
}

async function getValueFor(key) {
     return await SecureStore.getItemAsync(key);
}

const getStatusText = (status) => {

     if (status == '1') {
          return 'Demo';
     }
     else if (status == '2') {
          return 'Email';
     }

     else if (status == '3') {
          return 'Dormant';
     }

     else if (status == '4') {
          return 'Unreachable';
     }

     else if (status == '5') {
          return 'Wrong Number';
     }

     else if (status == '6') {
          return 'Others';
     }

     else if (status == '7') {
          return 'Later';
     }

     else if (status == '8' || status == '9' || status == '10' || status == '12') {
          return 'Others';
     }

     else if (status == '11') {
          return 'Comment';
     }

     else if (status == '13') {
          return 'Converted';
     }
     else {
          return 'N/A';
     }
}
var statusNo = '';
const LeadsListScreen = ({ navigation }) => {

     const [leads, setResult] = useState([]);
     const [title, setTitle] = useState('');
     const [errorText, setErrorText] = useState('');
     const [searchQuery, setSearchQuery] = useState('');

     const refresh = (data) => {
          fetchData();
     }

     useEffect(() => {
          const subscription = navigation.addListener(
               'didFocus',
               payload => {
                    fetchData();
               }
          );
          return () => {
               subscription.remove();
          }
     }, [])

     const handleBackButtonClick = () => {
          navigation.pop();
     }

     const fetchData = async () => {
          setTitle(await getStatusNo(navigation.state.params.id));
     }

     const getStatusNo = async (status) => {
          if (status == 'demo') {
               setResult(await handleList('1'));
               return 'Demo';
          }
          else if (status == 'email') {
               setResult(await handleList('2'));
               return 'Email';
          }

          else if (status == 'dormant') {
               setResult(await handleList('3'));
               return 'Dormant';
          }

          else if (status == 'unreachable') {
               setResult(await handleList('4'));
               return 'Unreachable';
          }

          else if (status == 'wrong_no') {
               setResult(await handleList('5'));
               return 'Wrong Number';
          }

          else if (status == 'others') {
               
               var result6 = await handleList('6');
               var result8 = await handleList('8');
               var result9 = await handleList('9');
               var result10 = await handleList('10');
               var result12 = await handleList('12');

               const finalResult = [...result6,...result8,...result9,...result10,...result12];

               setResult(finalResult);

               return 'Others';
          }

          else if (status == 'later') {
               setResult(await handleList('7'));
               return 'Later';
          }

          else if (status == 'comment') {
               setResult(await handleList('11'));
               return 'Comment';
          }

          else if (status == 'coverted') {
               setResult(await handleList('13'));
               return 'Converted';
          }
          else {
               setResult([]);
               return 'N/A';
          }
     }

     const handleList = async (status) => {
          statusNo = status;
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          setErrorText('');
          var response = await axios({
               method: 'post',
               url: `${Links.baseUrl}api/user-leads`,
               headers: {
                    common: {
                         Accept: 'application/x-www-form-urlencoded',
                    }
               },
               data: { userID: userInfo._id, status: status }
          });
          setErrorText('');
          setResult([]);
          if (response.data.success) {
               if (response.data.data) {
                    if (response.data.data.length == 0) {
                         setErrorText('No results found!');
                    }
                    return response.data.data.sort(function(a, b){return new Date(a.feedback[a.feedback.length - 1].date).toDateString() - new Date(b.feedback[b.feedback.length - 1].date).toDateString()}).reverse();
               }
               else {
                    setErrorText('No results found!');
                    return [];
               }
          }
          else {
               setErrorText('No results found!');
               return [];
          }
     }

     const handleSearch = async (searchQuery) => {
          let userInfo = await getValueFor('userInfo');
          userInfo = JSON.parse(userInfo);
          if (!searchQuery) {
               setErrorText('Kindly enter a query before searching.');
               return;
          }
          else {
               setErrorText('');
               axios({
                    method: 'post',
                    url: `${Links.baseUrl}api/search`,
                    headers: {
                         common: {
                              Accept: 'application/x-www-form-urlencoded',
                         }
                    },
                    data: { query: searchQuery, userID: userInfo._id, status: statusNo }
               }).then(function (response) {
                    setErrorText('');
                    setResult([]);
                    console.log(response.data);
                    if (response.data.success) {
                         if (response.data.data) {
                              setResult([response.data.data]);
                         }
                         else {
                              setErrorText('No results found!');
                         }
                    }
                    else {
                         setErrorText('No results found!');
                    }
               })
          }
     }

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>

               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
               <TextInput
                    style={{ ...styles.input, flex: 1 }}
                    onChangeText={setSearchQuery}
                    value={searchQuery}
                    caretHidden={false}
                    placeholder={`Search through ${title}`}
               />

               <View style={{ width: 10, }} />
               <TouchableOpacity activeOpacity={.5} onPress={() => {
                    handleSearch(searchQuery);
               }}>
                    <View style={styles.buttonBackground}>
                         <Ionicons name="ios-search" size={24} color="white" />
                    </View>
               </TouchableOpacity>
          </View>

          <Text style={{ ...styles.title, }}>
               {title} Leads
          </Text>
          {errorText ? <Text style={{ ...styles.errorText, }}>
               {errorText}
          </Text> : null}
          <FlatList data={leads} keyExtractor={(item) => item._id} contentContainerStyle={{ justifyContent: 'center', padding: 10 }} renderItem={({ item }) => {
               const statusText = getStatusText(item.status);
               return (<View style={{
                    backgroundColor: 'white', borderRadius: 10, marginVertical: 5,
                    elevation: 5,
                    shadowOpacity: 0.26,
                    shadowColor: 'black',
                    shadowRadius: 10,
                    padding: 10,
                    shadowOffset: { width: 0, height: 2 },
               }}>
                    <Text style={styles.title}>
                         {item.companyName}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 14, color: 'red' }}>
                         Status: {statusText}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 12, color: 'red' }}>
                         {getStatusText(item.feedback[item.feedback.length - 1].feedback)} on {new Date(item.feedback[item.feedback.length - 1].date).toDateString()}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         {item.fullName}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         {item.address}, {item.city}, {item.state}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         Mobile: {item.mobile1}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         Alternate Mobile: {item.mobile2}
                    </Text>
                    <Text style={{ ...styles.title, fontSize: 10 }}>
                         Email: {item.email}
                    </Text>
                    <View style={{ flexDirection: 'row', }}>
                         {item.status != '13' && item.status != '3' ? <TouchableOpacity activeOpacity={.5} onPress={() => {
                              navigation.navigate('Recontact', {
                                   leadData: item,
                                   onGoBack: refresh,
                              });
                         }}>
                              <View style={styles.buttonBackground}>
                                   <Text style={styles.buttonText}>Contact</Text>
                              </View>
                         </TouchableOpacity> : null}
                         <View style={{ width: 10, }} />
                         <TouchableOpacity activeOpacity={.5} onPress={() => {
                              navigation.navigate('LeadDetails', {
                                   leadData: item
                              });
                         }}>
                              <View style={styles.buttonBackground}>
                                   <Text style={styles.buttonText}>View Details</Text>
                              </View>
                         </TouchableOpacity>
                    </View>
               </View>);
          }} />
     </View>);
}

const styles = StyleSheet.create({
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          paddingHorizontal: 20,
          paddingTop: 50,
          justifyContent: 'center',

     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 5,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          paddingHorizontal: 10,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 14,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     dropDownTextStyle: {
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'red'
     },
     dropDownContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5,
          marginTop: 10,
     },
     itemContainer: {
          borderWidth: 1,
          backgroundColor: 'rgba(240,240,240,1)',
          borderRadius: 5,
          padding: 10,
          marginTop: 5,
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
     errorText: {
          fontFamily: 'open-sans-bold',
          fontSize: 12,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'red',
          alignItems: 'center',
          textAlign: 'center'
     },
});

export default LeadsListScreen;