import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity } from 'react-native';

const ChangePasswordScreen = ({ navigation }) => {
     const [number, onChangeNumber] = useState(null);

     return (<View style={styles.baseContainer}>
          <View style={styles.textBackground}>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    Forex
               </Text>
               <Text style={{ ...styles.title, color: 'blue', fontSize: 30 }}>
                    blues{' '}
               </Text>
               <Text style={{ ...styles.title, fontSize: 30 }}>
                    CRM
               </Text>
          </View>
          <Text style={{ ...styles.title, }}>
               Enter your new password!
          </Text>
          <TextInput
               style={styles.input}
               onChangeText={onChangeNumber}
               value={number}
               caretHidden={false}
               secureTextEntry
               placeholder='Enter your password'
               keyboardType="numeric"
          />
          <TextInput
               style={styles.input}
               onChangeText={onChangeNumber}
               value={number}
               caretHidden={false}
               secureTextEntry
               placeholder='Confirm your password'
               keyboardType="numeric"
          />
          <TouchableOpacity activeOpacity={.5} onPress={() => {
               navigation.navigate('Home');
          }}>
               <View style={styles.buttonBackground}>
                    <Text style={styles.buttonText}>Change Password</Text>
               </View>
          </TouchableOpacity>
     </View>);
}

const styles = StyleSheet.create({
     baseContainer: {
          flex: 1,
          backgroundColor: 'white',
          padding: 20,
          paddingTop: 50,
          justifyContent: 'center',
     },
     textBackground: {
          flexDirection: 'row',
          marginTop: 10,
     },
     textBackgroundRegister: {
          flexDirection: 'row',
          alignItems: 'flex-end',
          marginTop: 50,
          justifyContent: 'center'
     },
     buttonBackground: {
          backgroundColor: 'black',
          width: Dimensions.get('window').width * 0.5,
          height: 40,
          marginTop: 10,
          borderColor: 'white',
          borderRadius: 5,
          justifyContent: 'center',
          alignItems: 'center'
     },
     buttonText: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          color: 'white'
     },
     title: {
          fontFamily: 'open-sans-bold',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 5,
          color: 'black'
     },
     input: {
          height: 45,
          borderWidth: 1,
          padding: 10,
          fontFamily: 'open-sans',
          fontSize: 16,
          letterSpacing: 0.6,
          marginTop: 10,
          backgroundColor: 'rgba(240,240,240,1)',
          borderColor: 'white',
          borderRadius: 5
     },
});

export default ChangePasswordScreen;